<?php
    session_start();
    if(!isset($_SESSION['username'])) {
        header('Location: home.php');
    }
?>

<!DOCTYPE <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Password Hashing Tutorial</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.4/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
</head>
<body>
    <section class="hero is-medium is-dark is-bold">
        <div class="hero-body">
            <div class="container">
                <h1 class="title">
                    My Profile
                </h1>
                <h2 class="subtitle">
                    Password Hashing Tutorial
                </h2>
            </div>
        </div>
        <div class="hero-foot">
            <nav class="tabs">
                <div class="container">
                    <ul><li><a href="signout.php" id="signoutBtn">Sign out</a></ul>
                </div>
            </nav>
        </div>
    </section>
    <section class="section">
        <div class="container">
            
            <h1 class="title">My Profile</h1>
            <h2 class="subtitle">
                View and Change your Account details below.
            </h2>
            <div class="tabs">
                <ul>
                    <li class="is-active">General</a></li>
                    <li><a>Personal</a></li>
                    <li><a>My Interests</a></li>
                    <li><a>Friends/Followers</a></li>
                    <li><a>Settings</a></li>
                </ul>
            </div>
            <div class="box">
                <div class="content">
                    <div class="field is-horizontal">
                        <div class="field-label is-normal">
                            <label class="label">Email Address:</label>
                        </div>
                        <div class="field-body">
                            <div class="field">
                                <p class="control">
                                    <input class="input is-static" type="email" value="<?php echo $_SESSION['username']; ?>" readonly>
                                </p>
                            </div>
                        </div>
                    </div>
                    
                
                </div>
            </div>
        </div>
        
    </section>
    <script type="text/javascript" src="js/modal.js"></script>
</body>
</html>